import numpy as np
import matplotlib as mpl
import pandas as pd
import matplotlib.pyplot as plt

#import torch
import numpy as np
import numpy as np
#m: multivariate ts
#lag_order:p
#F: shape(mp*mp)
#Q: shape(mp*mp)
def calculate_p0(m,lag_order,A_star,Q):
    i_matrix=np.identity(m*m*lag_order*lag_order)
    # print('F')
    # print(F)
    i_F_F=i_matrix-np.kron(A_star,A_star)
    #inverse

    Q_transposed = np.transpose(Q)
    # print('Q')
    # print(Q)
    #print(torch.eig(Q, eigenvectors=False, out=None))
    r=Q.shape[0]
    c=Q.shape[1]
    vec_Q = Q_transposed.reshape((r * c, 1))
    #
    vec_p0=np.matmul(np.linalg.inv(i_F_F),vec_Q)
    #
    p0_temp=vec_p0.reshape((m*lag_order,m*lag_order))
    #
    p0=np.transpose(p0_temp)
    # print('p0')
    # print(p0)
    return (p0)


def get_A_coeff_m_for_VAR_1(inital_A_m,m,lag_order):
    r"""
        Put VAR(p) into VAR(1) and get coeffs matrix of state equation.
        Parameters
        ----------
        inital_A_m
           description: initial A coeffs
           type: tensor shape(m*m*p)
        m
           description: the dimension of ts
           type: int
        lag_order
           description: the lag of VAR model
        type: int

        Returns
        -------
        coeffs matrix of state equation.
    """
    F_list=[]
    for c in range(lag_order):
        F_list.append(inital_A_m[:,:,c])
    #concentrate
    F_temp1=np.concatenate(F_list, axis=1)

    mp=m*lag_order
    added_tensor= np.eye((mp-m), mp)
    coffs_m=np.concatenate((F_temp1, added_tensor), 0)
    return coffs_m

def make_var_cov_of_innovations_var1(var_cov_matrix_of_varp,m,lag_order):
    r"""
        Put VAR(p) into VAR(1) and get var-cov matrix of innovations of state equation.
        Parameters
        ----------
        lower_triang_params_form_lstm
           description: elements for lower triangular matrix for generating var-cov matrix
           type: tensor shape((m*(m+1)/2)，)
        m
           description: the dimension of ts
           type: int
        lag_order
           description: the lag of VAR model
        type: int

        Returns
        -------
        var-cov matrix of innovations of state euqation
    """
    mp=m*lag_order
    number_of_parms=m*(m+1)/2
#diag
    var_cov_matrix = var_cov_matrix_of_varp

    zeros_cols = np.zeros((m, (mp - m)))
    #2.generate (mp-m)*mp matrix
    zeros_rows = np.zeros(((mp - m),mp ))
    #print('Q_covariance')
    #print(var_cov_matrix)
    c = np.concatenate((var_cov_matrix, zeros_cols), axis=1)
    var_cov_of_innovations_for_var1 =np.concatenate((c, zeros_rows), axis=0)
    return (var_cov_of_innovations_for_var1)
###add stationarity for F
###define transformation to make the model stationary
#make F statisfies the param space to keep the model sationary
#A_coeffs: shape: (d,d,p)
#return all_A.shape:d*d*p
def A_coeffs_for_causal_VAR(A_coeffs,p,d,var_cov_innovations_varp):
    Id = np.identity(d)
    all_p = np.random.randn(d, d, p)
    # F_1 = F_out_network.reshape(d, d, p)
    #cal gamma 0
    #big_A_coffs_for_var1=get_A_coeff_m_for_VAR_1(A_coeffs, d, p)
    #Gamma_0=calculate_Gamma0(d, p, big_A_coffs_for_var1, var_cov_innovations_var1)
    for i1 in range(p):
        A = A_coeffs[:, :, i1]
        # print('A')
        # print(A)
        B = np.linalg.cholesky(Id + np.matmul(A,  np.transpose(A)))
        # print('B')
        # print(B)
        #all_p[:, :, i1] = torch.solve(A, B)[0]
        all_p[:, :, i1]=np.linalg.solve(B, A)
        # all_p[:,:,i1]=torch.triangular_solve(A,B)[0]
        # print('solve_A_B')
        # print(torch.solve(A, B)[0])
        # print('triangle_solver')
        # print(torch.triangular_solve(A, B)[0])

    all_phi = np.random.randn(d, d, p, p)  # [ , , i, j] for phi_{i, j}
    # all_phi=all_phi.clone()
    all_phi_star = np.random.randn(d, d, p, p)  # [ , , i, j] for phi_{i, j}*
    # all_phi_star=all_phi_star.clone()
    # Set initial values
    Sigma = Id
    Sigma_star = Id
    L = Id
    L_star = L

    # Recursion algorithm (Ansley and Kohn 1986, lemma 2.1)
    for s in range(p):
        all_phi[:, :, s, s] = np.matmul(np.matmul(L, all_p[:, :, s]), np.linalg.inv(L_star))
        # print('1')
        # print(torch.mm(torch.mm(L, all_p[:, :, s]), torch.inverse(L_star)))
        all_phi_star[:, :, s, s] = np.matmul(np.matmul(L_star, np.transpose(all_p[:, :, s])), np.linalg.inv(L))
        # print('2')
        # print(torch.mm(torch.mm(L_star, all_p[:, :, s].t()), torch.inverse(L)))
        if s >= 1:
            for k in list(range(1, s + 1)):
                all_phi[:, :, s, k - 1] = all_phi[:, :, s - 1, k - 1] - np.matmul(all_phi[:, :, s, s],
                                                                                 all_phi_star[:, :, s - 1, s - k])
                all_phi_star[:, :, s, k - 1] = all_phi_star[:, :, s - 1, k - 1] - np.matmul(all_phi_star[:, :, s, s],
                                                                                           all_phi[:, :, s - 1, s - k])

        Sigma_next = Sigma - np.matmul(all_phi[:, :, s, s], np.matmul(Sigma_star, np.transpose(all_phi[:, :, s, s])))
        Sigma_star = Sigma_star - np.matmul(all_phi_star[:, :, s, s],
                                                    np.matmul(Sigma,  np.transpose(all_phi_star[:, :, s, s])))
                # print('Sigma_star')
                # print(Sigma_star)
        L_star = np.linalg.cholesky(Sigma_star)
        Sigma = Sigma_next
            # print('Sigma')
            # print(Sigma)
        L = np.linalg.cholesky(Sigma)

    #cal T
    lower_t_for_innovations_varp=np.linalg.cholesky(var_cov_innovations_varp)
    T=np.matmul(lower_t_for_innovations_varp,np.linalg.inv(L))

    all_A = all_phi[:, :, p - 1, 0:p]
    #all_A.shape:d*d*p
    print(all_A.shape)
    print('F_sub')
    for i in range(p):
        all_A[:,:,i]=np.matmul(np.matmul(T,all_A[:,:,i]),np.linalg.inv(T))
        print('A-coeffs')
        print(all_A[:,:,i])
    return all_A




def sim_VARwT(m,p,sim_num,saving_path):
    A1_coeffs_original=np.array([[-1.1068,0.1343,0.07193],
                           [-1.0786,-0.2373,-0.1543],
                           [0.7889,0.3899,0.0706]])
    A2_coeffs_original=np.array([[-0.3951,-0.2855,-0.2222],
                           [-0.9916,0.4168,0.4047],
                           [0.3644,-0.5241,0.2809]])
    A_coeffs = np.random.randn(m, m, p)
    A_coeffs[:,:,0]=A1_coeffs_original
    A_coeffs[:,:,1]=A2_coeffs_original
    L=np.array([[0.7,0,0],
               [-0.4,0.5,0],
               [0.2,0.1,-0.6]])
    var_cov_varp=np.matmul(L,L.T)
    var_cov_innovations_varp=var_cov_varp

# var_cov_varp
# [[ 0.49 -0.28  0.14]
#  [-0.28  0.41 -0.03]
#  [ 0.14 -0.03  0.41]]
    all_A=A_coeffs_for_causal_VAR(A_coeffs,p,m,var_cov_innovations_varp)
    A=np.concatenate((all_A[:,:,0],all_A[:,:,1]), axis=1)
    mean=[0,0,0]
    mean_initial_p_obs=[0,0,0,0,0,0]
    #trend=pd.read_csv(trend_path)
    T=800
    #T=trend.shape[0]
    #y_intial (y_{0},y_{-1})'
    #cal var_cov of first p obs (y_p,..,y_1)
    A_star=get_A_coeff_m_for_VAR_1(all_A,m,p)
    Q=make_var_cov_of_innovations_var1(var_cov_innovations_varp,m,p)
    var_cov_first_p_obs=calculate_p0(m,p,A_star,Q)
    #y_inital: (y_p,...,y_1)
    y_inital=np.random.multivariate_normal(mean_initial_p_obs, var_cov_first_p_obs, 1).reshape(m*p,1)
    #put first p obs into matrix
    all_y_t=np.ones((T,m))
    for i in range(p):
        t=p-i-1
        begin_position=i*m
        end_position=i*m+m
        all_y_t[t,:]=y_inital[begin_position:end_position,0]



    # y_inital=np.array([[0],
    #                    [0.2],
    #                    [-0.3],
    #                    [0.3],
    #                    [0.3],
    #                    [0.1]])
    
    for t in range(p,T):
        y_t=np.matmul(A, y_inital)+np.random.multivariate_normal(mean, var_cov_varp, 1).reshape(m,1)
        print('y_inital')
        print(y_inital)
        #update y_initial
        #delete
        y_inital=np.concatenate((y_t,y_inital[0:m,0].reshape(m,1)), axis=0)
        all_y_t[t,:]=y_t[:,0]
        #not add trend
    #final_y_t=all_y_t+(np.array(trend.iloc[:,1:]))
    final_y_t=all_y_t
    df = pd.DataFrame(final_y_t)
    df.to_csv(saving_path+'exp'+str(sim_num)+'_len800_VAR2_m3_stationary_train.csv')

#real A coeffs (satisfy casuality condition)
# A-coeffs
# [[-1.08427023 -0.12458242  0.31367755]
#  [-0.70075495 -0.37537995 -0.20636599]
#  [ 0.31663506  0.32512408  0.21348637]]
# A-coeffs
# [[-0.54492268 -0.30519439 -0.1952287 ]
#  [-0.40570616  0.51291754  0.36554232]
#  [ 0.00536271 -0.29109937  0.20656285]]
from seed import *
saving_path='./simulation-study/sim_exp100/simulated_data_len800_VAR2_m3_stationary/'
#trend_path='/Users/xixili/Tsinghua Dropbox/XixiLi/deep-factors/trend_from_real_data/trend-len800-kernal-for-varwT.csv'
m=3
p=2
for i in range(100):
    seed_value=i
    set_global_seed(seed_value)
    sim_VARwT(m,p,i,saving_path)